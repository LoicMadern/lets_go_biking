﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy
{
    public class ServiceProxyHttp  : IServiceProxyHttp
    {
        ProxyCache<JCDecauxItem> cache = new ProxyCache<JCDecauxItem>();


        public void GetAllStations()
        {
            return;
        }

        public string GetSpecificStation(string station_number)
        {
            Debug.WriteLine("trying to get the station number :" + station_number);
            return (cache.Get(station_number)).content;
        }

    }
}
