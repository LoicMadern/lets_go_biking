var latitude_beginning
var latitude_arrival
var longitude_beginning
var longitude_arrival

var current_layer
var map




map = new ol.Map({
    target: 'map', // <-- This is the id of the div in which the map will be built.
    layers: [
        new ol.layer.Tile({
            source: new ol.source.OSM()
        })
    ],

    view: new ol.View({
        center: ol.proj.fromLonLat([6.178289, 48.690303]), // <-- Those are the GPS coordinates to center the map to.
        zoom: 13 // You can adjust the default zoom.
    })

});


function markBeginning() {

    latitude_beginning = parseFloat(document.getElementById("latitudeBeginning").value);
    longitude_beginning = parseFloat(document.getElementById("longitudeBeginning").value);

    latitude_arrival = parseFloat(document.getElementById("latitudeArrival").value);
    longitude_arrival = parseFloat(document.getElementById("longitudeArrival").value);

    var layer = new ol.layer.Vector({
        source: new ol.source.Vector({
            features: [
                new ol.Feature({

                    geometry: new ol.geom.Point(ol.proj.fromLonLat([latitude_arrival, longitude_arrival]))
                }),
                new ol.Feature({

                    geometry: new ol.geom.Point(ol.proj.fromLonLat([latitude_beginning, longitude_beginning]))
                })
            ]
        })
    });

    if(layer != current_layer){

        map.removeLayer(current_layer);
        var center_latitude;
        var center_longitude;


        if (latitude_beginning=>longitude_beginning){
            center_latitude = Math.abs(latitude_beginning - latitude_arrival)/2+latitude_beginning;
        }else {
            center_latitude = Math.abs(latitude_beginning - latitude_arrival)/2+latitude_arrival;
        }

        if (longitude_beginning=>longitude_beginning){
            center_longitude = Math.abs(longitude_beginning - longitude_arrival)/2+longitude_beginning;
        }else {
            center_longitude = Math.abs(longitude_beginning - longitude_arrival) / 2 + longitude_arrival;
        }

        map.getView().setCenter(ol.proj.transform([center_latitude, center_longitude], 'EPSG:4326', 'EPSG:3857'));


        map.addLayer(layer);
        current_layer = layer;
    }


}





/*
var layer = new ol.layer.Vector({
    source: new ol.source.Vector({
        features: [
            new ol.Feature({
                geometry: new ol.geom.Point(ol.proj.fromLonLat([7.0985774, 43.6365619]))
            })
        ]
    })
});
map.addLayer(layer);


// Create an array containing the GPS positions you want to draw
var coords = [[7.0985774, 43.6365619], [7.1682519, 43.67163]];
var lineString = new ol.geom.LineString(coords);

// Transform to EPSG:3857
lineString.transform('EPSG:4326', 'EPSG:3857');

// Create the feature
var feature = new ol.Feature({
    geometry: lineString,
    name: 'Line'
});

// Configure the style of the line
var lineStyle = new ol.style.Style({
    stroke: new ol.style.Stroke({
        color: '#ffcc33',
        width: 10
    })
});

var source = new ol.source.Vector({
    features: [feature]
});

var vector = new ol.layer.Vector({
    source: source,
    style: [lineStyle]
});

map.addLayer(vector);
*/

